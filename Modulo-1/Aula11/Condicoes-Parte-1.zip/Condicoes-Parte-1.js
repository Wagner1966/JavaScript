var vel = 60.5;
console.log(`A velocidade é ${vel} km/h`);

if (vel>60)
{
    console.log('Multado !!!');
}
else
{
    console.log('Digija com cuidado !!!');
}

var pais = 'EUA';

if (pais == 'Brasil')
{
    console.log('\n brasileiro');
}
else
{
    console.log(`\n estrangeiro ${pais}`);
}

console.log('\n <<< O console funcionou corretamente >>>');