var idade = 22;

if (idade<18)
{
    console.log('Menor de idade');
}
else
{
    console.log('Maior de idade');
}

// ------------------------------------

var agora = new Date();
var diaSemana = agora.getDay();

switch(diaSemana)
{
    case 0:
        console.log('Domingo');
        break;
    case 1:
        console.log('Segunda');
        break;
    case 2:    
        console.log('Terça');
        break;
    case 3:    
        console.log('Quarta');
        break;
    case 4:    
        console.log('Quinta');
        break;
    case 5:    
        console.log('Sexta');
        break;
    default:    
        console.log('Sábado');
        break;
}