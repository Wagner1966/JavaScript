//window.alert('<<< Ola >>>');

function tabuada()
{
    let txtnum = window.document.getElementById('txtnum');
    let seltab = window.document.getElementById('seltab');

    if (txtnum.value.length == 0)
    {
        window.alert('<<< Favor digitar um número >>>>');
        return;
    }

    let num = Number(txtnum.value);
    seltab.innerHTML = '';

    for (let c=1; c <= 10; c++)
    {
        let item = window.document.createElement('option');
        item.text = `${num} x ${c} = ${num*c}`
        item.value = `tab${c}`;
        seltab.appendChild(item);
    }
}