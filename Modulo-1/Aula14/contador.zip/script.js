//window.alert('<<< Ola >>>');

function contar()
{
    let txtinicio = window.document.getElementById('txtinicio');
    let txtfim = window.document.getElementById('txtfim');
    let txtpasso = window.document.getElementById('txtpasso');

    if (txtinicio.value.length == 0 || txtfim.value.length == 0 || txtpasso.value.length == 0)
    {
        window.alert('<<< Favor infomar valores acima >>>');
        return;
    }

    let x = 0;
    let i = Number(txtinicio.value);
    let f = Number(txtfim.value);
    let p = Number(txtpasso.value);

    if (p <= 0)
    {
        window.alert('<<< Passo inválido >>>');
        return;
    }

    let res = window.document.getElementById('res');
    res.innerHTML = 'Contando... <br>';

    if (i <= f)
    {
        //crescente
        for( x = i; x <= f; x += p )
        {
            res.innerHTML += `${x},  \u{1F920} `;
        }
    }
    else
    {
        //regressiva
        for( x = i; x >= f; x -= p )
        {
            res.innerHTML += `${x},  \u{1F920} `;
        }
    }

    res.innerHTML += `\u{1F3c1}`;
}