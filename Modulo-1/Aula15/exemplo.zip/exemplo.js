let num = [4.3, 2.5, 5.5, 7.1, 1.6];

for (let x = 0; x < num.length; x++)
{
    console.log(num[x]);
}

console.log('\n --------------------------------');
num[5] = 6.2;

for (let x = 0; x < num.length; x++)
{
    console.log(num[x]);
}

console.log('\n --------------------------------');
num.push(17); // última posição

for (let x = 0; x < num.length; x++)
{
    console.log(num[x]);
}

console.log('\n --------------------------------');
console.log('Tamanho array.: ' + num.length);

console.log('\n --------------------------------');
num.sort();

for (let x = 0; x < num.length; x++)
{
    console.log(num[x]);
}

console.log('\n --------------------------------');
console.log('Posição.: ' + num.lastIndexOf(2.5));
console.log('Não achou.: ' + num.lastIndexOf(2));