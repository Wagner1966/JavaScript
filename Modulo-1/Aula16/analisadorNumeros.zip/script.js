//window.alert('<<< Ola >>>');

let txtNumber = window.document.getElementById('txtNumber');
let selLista = window.document.getElementById('selLista');
let resposta = window.document.getElementById('res');
let valores = [];

function adicionar()
{
    let n = Number(txtNumber.value);

    if (isNumero(n) && !inLista(n, valores))
    {
        valores.push(n);
        //valores.sort();
        
        let item = window.document.createElement('option');
        item.text = `Valor ${n} adicionado`;

        selLista.appendChild(item);
        resposta.innerHTML = '';
    }
    else
    {
        window.alert('Valor inválido ou já existe na lista');
    }

    txtNumber.value = '';
    txtNumber.focus();
}

function isNumero(numero)
{
    //window.alert(numero);

    if (numero == null || !(numero >= 1 && numero <= 100) )
    {
        return false;
    }

    return true;
}

function inLista(numero, aLista)
{
    if ( aLista.indexOf(numero) != -1 )
    {
        return true;
    }

    return false;
}

function finalizar()
{
    let eleTotal = valores.length;

    if (eleTotal == 0)
    {
        window.alert('Não há valores para analizar');
        return;
    }

    let maior = valores[0];
    let menor = valores[0];
    let soma = 0;
    let media = 0;

    for (let x = 0; x < eleTotal; x++)
    {
        if (maior < valores[x+1])
        {
            maior = valores[x+1];
        }

        if (menor > valores[x+1])
        {
            menor = valores[x+1];
        }

        soma += valores[x];
    }

    media = soma / eleTotal;

    resposta.innerHTML = '';
    resposta.innerHTML += `<p>Ao todo temos ${eleTotal} números cadastrados</p>`;
    resposta.innerHTML += `<p>O maior valor é ${maior}</p>`;
    resposta.innerHTML += `<p>O menor valor é ${menor}</p>`;
    resposta.innerHTML += `<p>A soma de todos os valores digitados é ${soma}</p>`;
    resposta.innerHTML += `<p>A média de todos os valores digitados é ${media}</p>`;
}