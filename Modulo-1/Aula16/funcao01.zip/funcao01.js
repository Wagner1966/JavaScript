function parimpar(n)
{
    if (n%2 == 0)
    {
        return 'par';
    }
    else
    {
        return 'impar';
    }
}

function soma(n1=0, n2=0)
{
    return n1 + n2;
}

console.log( parimpar(4) );
console.log( parimpar(15) );

console.log(  `A soma é ${soma(15,17)}` );
console.log(  `A soma é ${soma(15)}` );


// //////////////////////////////////////////////////////
let x = function(y){ return y**2; };

console.log(`O quadrado é ${x(8)}`);


// //////////////////////////////////////////////////////
function fatorial(n)
{
    let fat = 1;

    for (let c = n; c > 1; c--)
    {
        fat *= c;
    }

    return fat;
}

console.log(`O fatorial é ${fatorial(5)}`);


// //////////////////////////////////////////////////////
function fatorialR(n)
{
    if (n == 1)
    {
        return 1;
    }

    return n * fatorialR(n-1);
}

console.log(`O fatorial é ${fatorialR(4)}`);