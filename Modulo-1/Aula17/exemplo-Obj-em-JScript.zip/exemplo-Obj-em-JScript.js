let amigo = 
{
    nome: 'José',
    sexo: 'M',
    peso: 75,
    engordar(p=0)
    {
        console.log('engordou');
        this.peso += p;
    }
};

console.log(typeof amigo);

amigo.engordar(2);
console.log(`${amigo.nome} do sexo ${amigo.sexo} pesa ${amigo.peso}kg`);

amigo.engordar(-3);
console.log(`${amigo.nome} do sexo ${amigo.sexo} pesa ${amigo.peso}kg`);